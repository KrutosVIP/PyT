A python project to Python Terminal.
-------------------------------------
A package with functions to Python Terminal v1.1
