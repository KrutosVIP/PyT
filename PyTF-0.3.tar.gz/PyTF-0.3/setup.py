import setuptools

with open("README.txt", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="PyTF",
    version="0.3",
    author="KrutosVIP",
    author_email="krutosviprus@gmail.com",
    description="A package to Python Terminal v1.1",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="Now,we don't have url :(",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU GPL v3",
        "Operating System :: Windows",
    ],
)